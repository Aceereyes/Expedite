<!doctype html>
<html lang="en">

<head>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</head>

<header id="header">

			<nav class="navbar navbar-default bg-info navbar-fixed-top navbar-sticky-function">

				<div class="container">
					
				<div class="logo-wrapper">
  			  	<div class="logo">
        		<a href="./"><img src="images/Expedite logo.png" alt="Logo" style="max-height: 55px;" class="img-responsive" /></a>
   				</div>

				</div>
					
					<div id="navbar" class="navbar-nav-wrapper navbar-arrow">
					
						<ul class="nav navbar-nav" id="responsive-menu">
						
							<li>
							
								<a href="./">HOME</a>
								
							</li>
							
							<li>
								<a href="job-list.php">JOB LIST</a>

							</li>
							
							<li>
								<a href="employers.php">EMPLOYERS</a>
							</li>
							
							<li>
								<a href="employees.php">FREELANCERS</a>
							</li>
							
							<li>
								<a href="contact.php">CONTACT US</a>
							</li>

						</ul>
				
					</div>

					<div class="nav-mini-wrapper">
						<ul class="nav-mini sign-in">
						<?php
						if ($user_online == true) {
						print '
						    <li><a href="logout.php">logout</a></li>
							<li><a href="'.$myrole.'">Profile</a></li>';
						}else{
						print '
							<li><a data-toggle="modal" data-target="#loginModal">Log-in</a></li>
							<li><a data-toggle="modal" href="#registerModal">Register</a></li>';						
						}
						
						?>

						</ul>
					</div>
				
				</div>
				
				<div id="slicknav-mobile"></div>
				
			</nav>
			
			<div id="loginModal" class="modal fade login-box-wrapper" tabindex="-1" style="display: none;" data-backdrop="static" data-keyboard="false" data-replace="true">
  			<div class="modal-dialog-centered">
   			 <div class="modal-content">
      		<div class="modal-header">
       		 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       		 <h4 class="modal-title text-center">Log-in to your Account</h4>
      		</div>
      <div class="modal-body">
        <div class="row gap-20">
          <div class="col-sm-6 col-md-6">
            <a href="login.php" class="btn btn-primary btn-block">Log-in as User</a>
          </div>
          <div class="col-sm-6 col-md-6">
            <a href="admin-login.php" class="btn btn-primary btn-block">Log-in as Administrator</a>
          </div>
        </div>
      </div>
      <div class="modal-footer text-center">
        <p>Don't have an account? <a data-toggle="modal" href="#registerModal">Register</a></p>
      </div>
    </div>
  </div>
</div>



			
			<div id="registerModal" class="modal fade login-box-wrapper" tabindex="-1" style="display: none;" data-backdrop="static" data-keyboard="false" data-replace="true">
			
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title text-center">Create your account for free</h4>
				</div>
				
				<div class="modal-body">
				
					<div class="row gap-20">
					
						<div class="col-sm-6 col-md-6">
							<a href="register.php?p=Employer" class="btn btn-facebook btn-block mb-5-xs">Register as Employer</a>
						</div>
						<div class="col-sm-6 col-md-6">
							<a href="register.php?p=Employee" class="btn btn-facebook btn-block mb-5-xs">Register as Freelancer</a>
						</div>

					</div>
				
				</div>
				
				<div class="modal-footer text-center">
					<button type="button" data-dismiss="modal" class="btn btn-primary btn-inverse">Close</button>
				</div>
				
			</div>

			

<?php 
require 'constants/settings.php'; 
$fromsearch = false;

if (isset($_GET['search']) && $_GET['search'] == "✓") {

}else{

}

if (isset($_GET['page'])) {
$page = $_GET['page'];
if ($page=="" || $page=="1")
{
$page1 = 0;
$page = 1;
}else{
$page1 = ($page*16)-16;
}					
}else{
$page1 = 0;
$page = 1;	
}

if (isset($_GET['country']) && ($_GET['category']) ){
$cate = $_GET['category'];
$country = $_GET['country'];	
$query1 = "SELECT * FROM tbl_jobs WHERE category = :cate AND country = :country ORDER BY enc_id DESC LIMIT $page1,12";
$query2 = "SELECT * FROM tbl_jobs WHERE category = :cate AND country = :country ORDER BY enc_id DESC";
$fromsearch = true;

$slc_country = "$country";
$slc_category = "$cate";
$title = "$slc_category jobs in $slc_country";
}else{
$query1 = "SELECT * FROM tbl_jobs ORDER BY enc_id DESC LIMIT $page1,12";
$query2 = "SELECT * FROM tbl_jobs ORDER BY enc_id DESC";	
$slc_country = "NULL";
$slc_category = "NULL";	
$title = "Job List";
}
            ?>

<div class="second-search-result-wrapper" style="background-color: #73bede	;">
  <div class="container ">
    <form action="job-list.php" method="GET" autocomplete="on">
      <div class="second-search-result-inner">
        <span class="labeling">Explore Jobs</span>
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-5">
            <div class="form-group form-lg">
              <input type="text" class="form-control" name="category" placeholder="Enter category" required />
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-5">
            <div class="form-group form-lg">
              <input type="text" class="form-control" name="country" placeholder="Enter country" required />
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-2">
            <button type="submit" class="btn btn-primary btn-block btn-lg">Search</button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
$(document).ready(function() {
    $('input[name="category"]').select2({
        placeholder: "Enter category",
        ajax: {
            url: "constants/get_categories.php",
            dataType: "json",
            delay: 250,
            data: function (params) {
                return {
                    q: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

    $('input[name="country"]').select2({
        placeholder: "Enter country",
        ajax: {
            url: "constants/get_countries.php",
            dataType: "json",
            delay: 250,
            data: function (params) {
                return {
                    q: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });
});
</script>

							
							</div>
						</div>
					
					</form>
					

				</div>
			
			</div>
            
            
            </header>