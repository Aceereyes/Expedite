<form name="frm" action="app/create-account.php" method="POST" autocomplete="off">
<div class="login-box-wrapper">
							
<div class="modal-header">
<h4 class="modal-title text-center">Create your account for free</h4>
</div>

<div class="modal-body">
																
<div class="row gap-20">
											

												

												
<div class="col-sm-12 col-md-12">

<div class="form-group"> 
<label>Company Name</label>
<input class="form-control" placeholder="Enter your company name" name="company" required type="text"> 
</div>
												
</div>

<div class="col-sm-12 col-md-12">

<div class="form-group"> 
<label>Company Type</label>
<input class="form-control" placeholder="Eg: Booking/Travel, Computer Software etc" name="type" required type="text"> 
</div>
												
</div>
												
<div class="col-sm-12 col-md-12">

<div class="form-group"> 
<label>Email Address</label>
<input class="form-control" placeholder="Enter your email address" name="email" required type="text"> 
</div>
												
</div>
												
<div class="col-sm-12 col-md-6">
    <div class="form-group"> 
        <label>Password</label>
        <div class="input-group">
            <input class="form-control" placeholder="Enter your password (min 8 and max 20 characters)" name="password" required type="password"> 
            <div class="input-group-append">
                <span class="input-group-text"><i class="fa fa-eye-slash"></i></span>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-12 col-md-6">
    <div class="form-group"> 
        <label>Password Confirmation</label>
        <div class="input-group">
            <input class="form-control" placeholder="Re-type your password (min 8 and max 20 characters)" name="confirmpassword" required type="password"> 
            <div class="input-group-append">
                <span class="input-group-text"><i class="fa fa-eye-slash"></i></span>
            </div>
        </div>
    </div>
</div>

<input type="hidden" name="acctype" value="101">

<script>
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    const showPasswordButtons = document.querySelectorAll('.input-group-text');

    showPasswordButtons.forEach((showPasswordButton, index) => {
        const passwordInput = passwordInputs[index];

        showPasswordButton.addEventListener('click', function() {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                showPasswordButton.innerHTML = '<i class="fa fa-eye"></i>';
            } else {
                passwordInput.type = 'password';
                showPasswordButton.innerHTML = '<i class="fa fa-eye-slash"></i>';
            }
        });
    });
</script>

</div>

</div>

<div class="modal-footer text-center">
<button  onclick="return val();" type="submit" name="reg_mode" class="btn btn-primary">Register</button>
</div>
										
</div>
</form>