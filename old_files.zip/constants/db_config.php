<?php
$servername = "srv613.hstgr.io";
$username = "u735446030_admin";
$password = "@Acdr1102";
$dbname = "u735446030_job_portal";
?>