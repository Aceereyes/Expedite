<!doctype html>
<html lang="en">
<?php 
include 'constants/settings.php'; 
include 'constants/check-login.php';
include 'header.php';
?>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Expedite</title>
	<meta name="description" content="Online Job Management / Job Portal" />
	<meta name="keywords" content="job, work, resume, applicants, application, employee, employer, hire, hiring, human resource management, hr, online job management, company, worker, career, recruiting, recruitment" />
	<meta name="author" content="Expedite PH">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta property="og:image" content="http://<?php echo "$actual_link"; ?>/images/banner.jpg" />
    <meta property="og:image:secure_url" content="https://<?php echo "$actual_link"; ?>/images/banner.jpg" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="500" />
    <meta property="og:image:height" content="300" />
    <meta property="og:image:alt" content="Expedite PH" />
    <meta property="og:description" content="Online Job Management / Job Portal" />

	<link rel="shortcut icon" href="images/ico/favicon.ico">


	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" media="screen">	
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/component.css" rel="stylesheet">
	
	<link rel="stylesheet" href="icons/linearicons/style.css">
	<link rel="stylesheet" href="icons/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="icons/simple-line-icons/css/simple-line-icons.css">
	<link rel="stylesheet" href="icons/ionicons/css/ionicons.css">
	<link rel="stylesheet" href="icons/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
	<link rel="stylesheet" href="icons/rivolicons/style.css">
	<link rel="stylesheet" href="icons/flaticon-line-icon-set/flaticon-line-icon-set.css">
	<link rel="stylesheet" href="icons/flaticon-streamline-outline/flaticon-streamline-outline.css">
	<link rel="stylesheet" href="icons/flaticon-thick-icons/flaticon-thick.css">
	<link rel="stylesheet" href="icons/flaticon-ventures/flaticon-ventures.css">
	<link href="css/style.css" rel="stylesheet">

	
</head>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-KR3K03CV5L"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KR3K03CV5L');
</script>

  <style>
  
    .autofit2 {
	height:70px;
	width:400px;
    object-fit:cover; 
  }
  
      .autofit3 {
	height:80px;
	width:100px;
    object-fit:cover; 
  }
  

  </style>
<body class="home">


	<div id="introLoader" class="introLoading"></div>


	<div class="container-wrapper">

		<div class="main-wrapper">
		
			<div class="hero" style="background-image:url('images/hero-header/banner.gif');">
				<div class="container">

					<h1> Searching For Freelancing Jobs Never Get This Easier </h1>
					<p> Apply Now In Expedite PH </p>


				</div>
				
			</div>

			
			<div class="post-hero bg-light">
			
				<div class="container">

					<div class="process-item-wrapper mt-20">
							
						<div class="row">
						
							<div class="col-sm-4">
								
								<div class="process-item clearfix">
									
									<div class="icon">
										<i class="flaticon-line-icon-set-magnification-lens"></i>
									</div>
									
									<div class="content">
										<h5>Step 01: Search for jobs</h5>
									</div>
									
								</div>
								
							</div>
							
							<div class="col-sm-4">
							
								<div class="process-item clearfix">
									
									<div class="icon">
										<i class="flaticon-line-icon-set-pencil"></i>
									</div>
									
									<div class="content">
										<h5>Step 02: Apply a Job</h5>
									</div>
									
								</div>
								
							</div>
							
							<div class="col-sm-4">
								
								<div class="process-item clearfix">
									
									<div class="icon">
										<i class="flaticon-line-icon-set-calendar"></i>
									</div>
									
									<div class="content">
										<h5>Step 03: Start Working</h5>
									</div>
									
								</div>
								
							</div>
							
						</div>
					
					</div>
					
				</div>
			
			</div>

			<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
			</div>

			<div class="container-fluid" style="background-color: #87C0D8;">
  <div class="row">
    <div class="col-md-4">
      <div style="background: linear-gradient(to bottom right, rgba(56,84,144,0.7), rgba(148,169,196,0.7)); border-radius: 10px; margin: 10px; text-align: center;">
        <img src="images/fb.png" alt="Facebook Container Image" style="display: block; margin: 20px auto 10px;">  
      </div>
    </div>
    <div class="col-md-4">
      <div style="background: linear-gradient(to bottom right, rgba(156,54,142,0.7), rgba(241,202,31,0.7)); border-radius: 10px; margin: 10px; text-align: center;">
        <img src="images/insta.png" alt="Instagram Container Image" style="display: block; margin: 20px auto 10px;">
      </div>
    </div>
    <div class="col-md-4">
      <div style="background: linear-gradient(to bottom right, rgba(81,163,226,0.7), rgba(214,220,225,0.7)); border-radius: 10px; margin: 10px; text-align: center;">
        <img src="images/twitter.png" alt="Twitter Container Image" style="display: block; margin: 20px auto 10px;">
      </div>
    </div>
  </div>
</div>


			
			<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
			</div>
			

			<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
    			<div class="container" style="background: linear-gradient(to left, #87C0D8, white); border-radius: 30px;">
        		<div class="row">
            	<div class="col-lg-6">
             	   <div class="mission-section">
                    <div class="mission-text">
                        <br><h2 class="text-center text-md-left mb-3">Our Mission</h2>
                        <p class="text-justify">Expedite's objective is to transform the freelancing sector by offering a simplified and accelerated platform that links businesses with highly experienced freelancers. We want to remove the hurdles that prevent efficient cooperation and provide freelancers the tools they need to perform their services swiftly and seamlessly. Through a hassle-free freelance experience, we hope to increase productivity, minimize project turnaround time, and assure customer satisfaction.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="mission-image">
                    <img src="images/mission.png" alt="Mission Image" class="img-responsive">
                </div>
            </div>
        </div>
    </div>

	<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
			</div>


			<div class="pt-3 pb-3 mt-15 mb-15" >
    		<div class="container" style="background: linear-gradient(to right, #87C0D8, white); border-radius: 30px;">
       		 <div class="vision-section">
           		 <div class="row">
           	     <div class="col-12 col-md-6 order-md-1">
                    <div class="vision-image-container mb-3 mb-md-0 text-center" style="margin-left: 50px; margin-top: 20px">
                        <img src="images/vision.png" alt="Mission Image" class="img-responsive">
                    </div>
                </div>
                <div class="col-12 col-md-6 order-md-2">
                    <div class="vision-text-container" style="margin-top: 50px;">
                        <h2 class="text-center text-md-left mb-3">Our Vision</h2>
                        <p class="text-justify">Our vision is to be the leading platform for accelerated freelancing services, known for our dedication to speed, quality, and customer satisfaction. We foresee a future in which organizations can readily access top-tier freelancing talent, shorten project schedules, and achieve their objectives more quickly than ever before. We try to be a trusted partner for organizations looking for quick solutions, as well as to provide freelancers with the tools and resources they need to flourish in a fast-paced, results-driven workplace. We aspire to revolutionize the freelancing environment and impact the future of work through cutting-edge technology and a devoted community.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
			</div>


<div class="container" style="background-color: rgba(209, 229, 244, 0.5); border-radius: 30px; margin-top: 20px">
  <div class="row">
    <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <div class="section-title">
        <br><h2>About Us</h2>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 text-center">
      <img src="images/try.jpg" style="max-width: 80%; height: auto; display: block; margin: auto;">
    </div>
  </div>

  <div class="row" style="margin-top: 50px; margin-bottom: 50px">
    <div class="col-md-6 col-md-offset-3 text-center" style="margin-size: 20px; text-justify">
      <p style="font-size: 20px; text-justify">We are a team of developers passionate about creating innovative software solutions for our clients. With years of experience in the industry, we have the skills and expertise to tackle even the most complex projects. Our goal is to help businesses succeed by providing them with the tools they need to thrive in today's digital world.</p>
    </div>
  </div>
</div>

<!-- Golveo Start -->
<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
			</div>

<div class="container" style="background-color: rgba(219, 220, 222, 0.5); border-radius: 30px; margin-top: 20px">
<div class="row" style="margin-top: 20px;" >
    <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <div class="section-title">
	  <br><h2 style="margin-bottom: -30px;">Expedite Administration</h2>
      </div>
    </div>
  </div>
  

  <div class="row" style="margin-bottom: 30px;">
  <div class="col-md-6 text-center">
    <h4 style="margin-top: 40px;">Website Administrator and Backend Programmer</h4>
	<h4 style="margin-bottom: 50px; color: blue;">Aaron Christian Delos Reyes</h4>
    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
      <img src="images/pf4.jpg" alt="Administrator 1" class="img-responsive" style="width: 70%; height: auto; border-radius: 50%; margin-bottom: 20px; border: 5px solid #333;">
    </div>
    <p style="margin-left: 50px; margin-right: 70px;">A third year student from National College of Science and Technology, leads the team into creation of Expedite PH</p>
  </div>

  <div class="col-md-6 text-center">
    <h4 style="margin-top: 40px;">Software Designer and Content Creator</h4>
	<h4 style="margin-bottom: 50px; color: blue;">Niel Adrian Lopez</h4>
    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
      <img src="images/pf2.jpg" alt="Administrator 2" class="img-responsive" style="width: 70%; height: auto; border-radius: 50%; margin-bottom: 20px; border: 5px solid #333;">
    </div>
    <p style="margin-left: 50px; margin-right: 70px;">A third year student from National College of Science and Techology, joins the team and leads the way into website designing for Expedite PH</p>
  </div>
</div>
  <div class="col-md-6 text-center">
    <h4 style="margin-top: 40px;">Secretary and System Analyst</h4>
	<h4 style="margin-bottom: 50px; color: blue;">Jan Michael Nicerio</h4>
    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
      <img src="images/pf3.jpg" alt="Administrator 3" class="img-responsive" style="width: 70%; height: auto; border-radius: 50%; margin-bottom: 20px; border: 5px solid #333;">
    </div>
    <p style="margin-left: 50px; margin-right: 70px;">A third year student from National College of Science and Technology, joins the team as he jots down details and create reports for Expedite PH</p>
  </div>

  <div class="col-md-6 text-center">
    <h4 style="margin-top: 40px;">Front-end Programmer System Debugger</h4>
	<h4 style="margin-bottom: 50px; color: blue;">John Kevin Golveo</h4>
    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
      <img src="images/pf1.jpg" alt="Administrator 4" class="img-responsive" style="width: 70%; height: auto; border-radius: 50%; margin-bottom: 20px; border: 5px solid #333;">
    </div>
    <p style="margin-left: 50px; margin-right: 70px;">A third year student from National College of Science and Technology, joins the team as he debugs the programs and help in front-end programming for Expedite PH</p>
	<div class="row" style="margin-bottom: 30px;">
</div>
</div>
</div>

<!-- Golveo End -->

<div class="pt-0 pb-50 " style="background-color: #87C0D8;">
			</div>

				<div class="pt-0 pb-50" style="background-color: rgba(209, 229, 244, 0.5); border-radius: 30px; margin-top: 20px">
			
				<div class="container">

					<div class="row">
					
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
							<div class="section-title">
							
								<br><h2>Companies Partnered With Expedite</h2>
								
							</div>
						
						</div>
					
					</div>
					
					<div class="row top-company-wrapper with-bg">

							
					<?php
					require 'constants/db_config.php';
					try {
                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = 'employer' ORDER BY rand() LIMIT 8");
                    $stmt->execute();
                    $result = $stmt->fetchAll();

                    foreach($result as $row) {
					$complogo = $row['avatar'];
					?>
					<div class="col-xss-12 col-xs-6 col-sm-4 col-md-3">
							
					<div class="top-company " style="border-radius: 30px;">
					<div class="image">
					<?php 
					if ($complogo == null) {
					print '<center><img class="autofit2" alt="image"  src="images/blank.png"/></center>';
					}else{
					echo '<center><img class="autofit2" alt="image"  src="data:image/jpeg;base64,'.base64_encode($complogo).'"/></center>';	
					}
					?>
					</div>
					<h6><?php echo $row['first_name'];?></h6>
					<a target="_blank" href="company.php?ref=<?php echo $row['member_no']; ?>">View Company</a>
					</div>
							
					</div>
					<?php
					
                    {

	                }
					  
	                }}catch(PDOException $e)
                    {

                    }
	
					?>
						

						
						
					</div>

				</div>

	
	
			
				<div class="container" style="background-color: #E8EEF2; border-radius: 30px; margin-top: 20px;">
				
					<div class="row">
						
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
							<div class="section-title" style="margin-top: 20px;">
							
								<h2>Latest Jobs</h2>
								
							</div>
						
						</div>
					
					</div>
					
					<div class="row " style="margin-bottom: 20px;">
						
						<div class="col-md-12">
						
							<div class="recent-job-wrapper alt-stripe mr-0">
							<?php
							require 'constants/db_config.php';
							try {
                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $stmt = $conn->prepare("SELECT * FROM tbl_jobs ORDER BY enc_id DESC LIMIT 8");
                            $stmt->execute();
                            $result = $stmt->fetchAll();
  

                            foreach($result as $row) {
							$jobcity = $row['city'];
							$jobcountry = $row['country'];
							$type = $row['type'];
							$title = $row['title'];
							$closingdate = $row['closing_date'];
							$company_id = $row['company'];
							$post_date = date('d', strtotime($closingdate));
                            $post_month = date('F', strtotime($closingdate));
                            $post_year = date('Y', strtotime($closingdate));
										   
							$stmtb = $conn->prepare("SELECT * FROM tbl_users WHERE member_no = '$company_id' and role = 'employer'");
                            $stmtb->execute();
                            $resultb = $stmtb->fetchAll();
							foreach($resultb as $rowb) {
							$complogo = $rowb['avatar'];
							$thecompname = $rowb['first_name'];	
								
							}
							
							if ($type == "Freelance") {
							$sta = '<div class="job-label label label-success">
									Freelance
									</div>';
											  
							}
							if ($type == "Part-time") {
							$sta = '<div class="job-label label label-danger">
									Part-time
									</div>';
											  
							}
							if ($type == "Full-time") {
							$sta = '<div class="job-label label label-warning">
									Full-time
									</div>';
											  
							}
							?>
							<a class="recent-job-item clearfix" target="_blank" href="explore-job.php?jobid=<?php echo $row['job_id']; ?>">
							<div class="GridLex-grid-middle">
							<div class="GridLex-col-5_xs-12">
							<div class="job-position">
							<div class="image">
							<?php 
							if ($complogo == null) {
							print '<center><img alt="image"  src="images/blank.png"/></center>';
							}else{
							echo '<center><img alt="image" title="'.$thecompname.'" width="180" height="100" src="data:image/jpeg;base64,'.base64_encode($complogo).'"/></center>';	
							}
							?>
							</div>
							<div class="content">
							<h4><?php echo "$title"; ?></h4>
							<p><?php echo "$thecompname"; ?></p>
							</div>
							</div>
							</div>
							<div class="GridLex-col-5_xs-8_xss-12 mt-10-xss">
							<div class="job-location">
							<i class="fa fa-map-marker text-primary"></i> <?php echo "$jobcountry" ?></strong> - <?php echo "$jobcity" ?>
							</div>
							</div>
							<div class="GridLex-col-2_xs-4_xss-12">
							<?php echo "$sta"; ?>
							<span class="font12 block spacing1 font400 text-center">Due - <?php echo "$post_month"; ?> <?php echo "$post_date"; ?>, <?php echo "$post_year"; ?></span>
							</div>
							</div>
							</a>
								
							<?php

                            }
	                        }catch(PDOException $e)
                            { 
                   
                             }
                             ?>
						



							
							</div>
							
						</div>
						
					</div>
					
				</div>

			
			</div>
			

			</div>
			


        </div>

    </div>
</div>


    </div>
</div>

			
		<?php 
			include 'footer.php';
			?>


<div id="back-to-top">
   <a href="#"><i class="ion-ios-arrow-up"></i></a>
</div>


<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-modalmanager.js"></script>
<script type="text/javascript" src="js/bootstrap-modal.js"></script>
<script type="text/javascript" src="js/smoothscroll.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/jquery.slicknav.min.js"></script>
<script type="text/javascript" src="js/jquery.placeholder.min.js"></script>
<script type="text/javascript" src="js/bootstrap-tokenfield.js"></script>
<script type="text/javascript" src="js/typeahead.bundle.min.js"></script>
<script type="text/javascript" src="js/bootstrap3-wysihtml5.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery-filestyle.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.js"></script>
<script type="text/javascript" src="js/ion.rangeSlider.min.js"></script>
<script type="text/javascript" src="js/handlebars.min.js"></script>
<script type="text/javascript" src="js/jquery.countimator.js"></script>
<script type="text/javascript" src="js/jquery.countimator.wheel.js"></script>
<script type="text/javascript" src="js/slick.min.js"></script>
<script type="text/javascript" src="js/easy-ticker.js"></script>
<script type="text/javascript" src="js/jquery.introLoader.min.js"></script>
<script type="text/javascript" src="js/jquery.responsivegrid.js"></script>
<script type="text/javascript" src="js/customs.js"></script>


</body>


</html>