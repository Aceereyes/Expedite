<!doctype html>
<html lang="en">
<header id="header">
  <nav class="navbar navbar-default bg-info navbar-fixed-top navbar-sticky-function">
    <div class="container">
      <div class="logo-wrapper">
        <div class="logo">
			<a href="../"><img src="../images/Expedite logo.png" alt="Logo" style="max-height: 50px;" /></a>
        </div>
      </div>
      <div id="navbar" class="navbar-nav-wrapper navbar-arrow">
        <ul class="nav navbar-nav" id="responsive-menu">
          <li>
            <a href="../">Home</a>
          </li>
          <li>
            <a href="../job-list.php">Job List</a>
          </li>
          <li>
            <a href="../employers.php">Employers</a>
          </li>
          <li>
            <a href="../employees.php">Employees</a>
          </li>
          <li>
            <a href="../contact.php">Contact Us</a>
          </li>
        </ul>
      </div>
      <div class="nav-mini-wrapper">
        <ul class="nav-mini sign-in">
          <li><a href="../logout.php">Log-out</a></li>
          <li><a href="./">Profile</a></li>
        </ul>
      </div>
    </div>
  </nav>
</header>
            
            </header>