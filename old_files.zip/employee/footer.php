<!doctype html>
<html lang="en">

<?php
$tw = "https://twitter.com/ExpeditePH";
$fb = "https://www.facebook.com/expeditephilippines";
$ig = "https://www.instagram.com/expediteph";
?>

<footer class="footer-wrapper">
			
				<div class="main-footer" style="background-color: #87C0D8;">

					<div class="container">
					
						<div class="row">
						
							<div class="col-sm-12 col-md-9">
							
								<div class="row">
								
									<div class="col-sm-6 col-md-4">
									
										<div class="footer-about-us">
										<div style="text-align: center;">
    										<h5 class="footer-title text-center">About Expedite</h5>
										</div>
											<p class="text-center">Expedite is a job portal, online job management system developed by Aaron Christian Delos Reyes, John Kevin Golveo, Jan Michael Nicerio, and Niel Adiran Lopez for his project in April 2023.</p>
										
										</div>

									</div>
									
									<div class="col-sm-6 col-md-8 mt-30-xs text-center">
    							<h5 class="footer-title">Quick Links</h5>
  								  <ul class="footer-menu clearfix">
      						 <li><a href="../">Home</a></li>
       						 <li><a href="../job-list.php">Job List</a></li>
      						  <li><a href="../employers.php">Employers</a></li>
      						  <li><a href="../employees.php">Freelancers</a></li>
      						  <li><a href="../contact.php">Contact Us</a></li>
       						 <li><a href="#">Go to top</a></li>
 							   </ul>
								</div>


								</div>

							</div>
							
							<div class="col-sm-12 col-md-3 mt-60-xs d-flex flex-column justify-content-center align-items-center">
    						<h5 class="footer-title text-center mb-3">Expedite Jobs Contact</h5>
    						<p class="text-center">Address : Amafel Building, Aguinaldo Highway, Dasmarinas, Cavite</p>
   							 <p class="text-center">Email : <a href="mailto:expeditephilippines@gmail.com">expeditephilippines@gmail.com</a></p>
    						<p class="text-center">Phone : <a href="tel:+639762728869">+63 976 272 8869</a></p>
							</div>


							
						</div>
						
					</div>
					
				</div>
				
				<div class="bottom-footer bg-info" >
				
					<div class="container">
					
						<div class="row">
						
							<div class="col-sm-4 col-md-4">
					
								<p class="copy-right">&#169; Copyright <?php echo date('Y'); ?> National College of Science and Technology</p>
								
							</div>
							
							<div class="col-sm-4 col-md-4">
							
								<ul class="bottom-footer-menu">
									<li><a >Developed by Group 7</a></li>
								</ul>
							
							</div>
							
							<div class="col-sm-4 col-md-4">
								<ul class="bottom-footer-menu for-social">
									<li><a href="<?php echo "$tw"; ?>"><i class="ri ri-twitter" data-toggle="tooltip" data-placement="top" title="twitter"></i></a></li>
									<li><a href="<?php echo "$fb"; ?>"><i class="ri ri-facebook" data-toggle="tooltip" data-placement="top" title="facebook"></i></a></li>
									<li><a href="<?php echo "$ig"; ?>"><i class="ri ri-instagram" data-toggle="tooltip" data-placement="top" title="instagram"></i></a></li>
								</ul>
							</div>
						
						</div>

					</div>
					
				</div>
</footer>